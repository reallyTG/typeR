library(CpGassoc)


### Name: Sample Data CpGassoc
### Title: Sample data from 'CpGassoc'
### Aliases: samplecpg samplepheno annotation
### Keywords: datasets

### ** Examples

##See help pages for other functions for usage of these datasets



