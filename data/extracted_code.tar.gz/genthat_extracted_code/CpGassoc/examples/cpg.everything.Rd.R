library(CpGassoc)


### Name: cpg.everything
### Title: Multi-Task function
### Aliases: cpg.everything cpg.everything.character cpg.everything.complex
###   cpg.everything.logical cpg.everything.matrix cpg.everything.numeric
### Keywords: ~kwd1 ~kwd2

### ** Examples

#Has four methods:character,complex, numeric/matrix, and logical
#They correspon to getting the indep variable name, warnings, getting the random function,
#and getting the names for the values returned. For the design of these functions see
#the R code. 



