library(CpGassoc)


### Name: cpg.work
### Title: Does the analysis between the CpG sites and phenotype of
###   interest
### Aliases: cpg.work
### Keywords: ~kwd1 ~kwd2

### ** Examples

##See the examples listed in cpg.assoc for ways in which to use cpg.work.
##Just change the cpg.assoc to cpg.work.



