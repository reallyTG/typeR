library(TeachBayes)


### Name: beta_draw
### Title: Draw a Beta Curve
### Aliases: beta_draw

### ** Examples

  parameters <- c(2, 5)
  beta_draw(parameters)



