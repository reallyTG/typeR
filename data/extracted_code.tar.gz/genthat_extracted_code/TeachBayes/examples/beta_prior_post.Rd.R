library(TeachBayes)


### Name: beta_prior_post
### Title: Plot of Two Beta Curves
### Aliases: beta_prior_post

### ** Examples

 beta_prior_post(c(4, 6), c(19, 16))



