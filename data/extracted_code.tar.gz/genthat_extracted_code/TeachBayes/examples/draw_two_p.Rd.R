library(TeachBayes)


### Name: draw_two_p
### Title: Plot of Distribution of Two Proportions
### Aliases: draw_two_p

### ** Examples

  Prob <- testing_prior()
  draw_two_p(Prob, title="Testing Prior")



