library(TeachBayes)


### Name: many_normal_plots
### Title: Graph of several normal curves
### Aliases: many_normal_plots

### ** Examples

 normal_parameters <- list(c(100, 15),
     c(110, 15), c(120, 15))
 many_normal_plots(normal_parameters)



