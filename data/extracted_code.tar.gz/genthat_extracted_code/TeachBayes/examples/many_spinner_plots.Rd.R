library(TeachBayes)


### Name: many_spinner_plots
### Title: Graphs a collection of spinners
### Aliases: many_spinner_plots

### ** Examples

  regions1 <- c(1, 1, 1)
  regions2 <- c(2, 1, 2, 1)
  many_spinner_plots(list(regions1, regions2))



