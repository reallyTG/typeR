library(TeachBayes)


### Name: normal_draw
### Title: Draws a Normal Curve
### Aliases: normal_draw

### ** Examples

  parameters <- c(2, 1)
  normal_draw(parameters)



