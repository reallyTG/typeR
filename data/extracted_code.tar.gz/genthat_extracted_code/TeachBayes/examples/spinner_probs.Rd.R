library(TeachBayes)


### Name: spinner_probs
### Title: Display probability distribution for a spinner
### Aliases: spinner_probs

### ** Examples

  sp <- c(2, 1, 1, 2)
  spinner_probs(sp)



