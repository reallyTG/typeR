library(coefplot)


### Name: invlogit
### Title: invlogit
### Aliases: invlogit

### ** Examples

invlogit(3)
invlogit(-6:6)
invlogit(c(-1, 1, 2))




