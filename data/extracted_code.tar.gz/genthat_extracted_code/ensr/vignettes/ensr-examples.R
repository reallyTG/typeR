### This is an R script tangled from 'ensr-examples.html.asis'
