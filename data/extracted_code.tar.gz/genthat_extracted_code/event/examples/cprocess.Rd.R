library(event)


### Name: cprocess
### Title: Plot Counting Process Data
### Aliases: cprocess
### Keywords: hplot

### ** Examples

times <- rgamma(20,2,scale=4)
cprocess(times)



