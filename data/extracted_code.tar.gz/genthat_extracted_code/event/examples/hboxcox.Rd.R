library(event)


### Name: hboxcox
### Title: Log Hazard Function for a Box-Cox Process
### Aliases: hboxcox
### Keywords: distribution

### ** Examples

hboxcox(2, 5, 5, 2)



