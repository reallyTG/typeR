library(event)


### Name: hburr
### Title: Log Hazard Function for a Burr Process
### Aliases: hburr
### Keywords: distribution

### ** Examples

hburr(2, 5, 1, 2)



