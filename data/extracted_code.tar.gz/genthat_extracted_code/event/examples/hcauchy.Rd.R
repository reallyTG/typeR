library(event)


### Name: hcauchy
### Title: Log Hazard Function for a Cauchy Process
### Aliases: hcauchy
### Keywords: distribution

### ** Examples

hcauchy(1:10, 3, 2)



