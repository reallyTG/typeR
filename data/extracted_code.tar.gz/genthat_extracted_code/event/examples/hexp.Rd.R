library(event)


### Name: hexp
### Title: Log Hazard Function for a Poisson Process
### Aliases: hexp
### Keywords: distribution

### ** Examples

hexp(1:10, 3)



