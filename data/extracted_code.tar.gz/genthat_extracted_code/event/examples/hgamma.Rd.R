library(event)


### Name: hgamma
### Title: Log Hazard Function for a Gamma Process
### Aliases: hgamma
### Keywords: distribution

### ** Examples

hgamma(1:10, 3, 2)



