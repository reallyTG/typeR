library(event)


### Name: hgextval
### Title: Log Hazard Function for an Extreme Value Process
### Aliases: hgextval
### Keywords: distribution

### ** Examples

hgextval(1, 2, 1, 2)



