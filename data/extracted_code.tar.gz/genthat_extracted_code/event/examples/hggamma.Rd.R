library(event)


### Name: hggamma
### Title: Log Hazard Function for a Generalized Gamma Process
### Aliases: hggamma
### Keywords: distribution

### ** Examples

hggamma(2, 5, 4, 2)



