library(event)


### Name: hglogis
### Title: Log Hazard Function for a Generalized Logistic Process
### Aliases: hglogis
### Keywords: distribution

### ** Examples

hglogis(5, 5, 1, 2)



