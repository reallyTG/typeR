library(event)


### Name: hgweibull
### Title: Log Hazard Function for a Generalized Weibull Process
### Aliases: hgweibull
### Keywords: distribution

### ** Examples

hgweibull(5, 1, 3, 2)



