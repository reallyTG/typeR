library(event)


### Name: hhjorth
### Title: Log Hazard Function for a Hjorth Process
### Aliases: hhjorth
### Keywords: distribution

### ** Examples

hhjorth(5, 5, 5, 2)



