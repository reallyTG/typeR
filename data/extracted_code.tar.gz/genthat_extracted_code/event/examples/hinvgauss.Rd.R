library(event)


### Name: hinvgauss
### Title: Log Hazard Function for a Inverse Gauss Process
### Aliases: hinvgauss
### Keywords: distribution

### ** Examples

hinvgauss(5, 5, 1)



