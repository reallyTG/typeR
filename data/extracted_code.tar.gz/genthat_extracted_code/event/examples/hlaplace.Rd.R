library(event)


### Name: hlaplace
### Title: Log Hazard Function for a Laplace Process
### Aliases: hlaplace
### Keywords: distribution

### ** Examples

hlaplace(5, 2, 1)



