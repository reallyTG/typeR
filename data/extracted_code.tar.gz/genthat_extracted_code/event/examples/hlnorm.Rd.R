library(event)


### Name: hlnorm
### Title: Log Hazard Function for a Log Normal Process
### Aliases: hlnorm
### Keywords: distribution

### ** Examples

hlnorm(1:10, 3, 2)



