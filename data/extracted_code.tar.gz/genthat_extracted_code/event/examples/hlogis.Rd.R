library(event)


### Name: hlogis
### Title: Log Hazard Function for a Logistic Process
### Aliases: hlogis
### Keywords: distribution

### ** Examples

hlogis(1:10, 3, 2)



