library(event)


### Name: hnorm
### Title: Log Hazard Function for a Normal Process
### Aliases: hnorm
### Keywords: distribution

### ** Examples

hnorm(1:10, 3, 2)



