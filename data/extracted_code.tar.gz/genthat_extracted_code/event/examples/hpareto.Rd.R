library(event)


### Name: hpareto
### Title: Log Hazard Function for a Pareto Process
### Aliases: hpareto
### Keywords: distribution

### ** Examples

hpareto(5, 2, 2)



