library(event)


### Name: hskewlaplace
### Title: Log Hazard Function for a Skew Laplace Process
### Aliases: hskewlaplace
### Keywords: distribution

### ** Examples

hskewlaplace(5, 2, 1, 0.5)



