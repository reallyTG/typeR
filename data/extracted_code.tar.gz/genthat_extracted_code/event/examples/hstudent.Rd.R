library(event)


### Name: hstudent
### Title: Log Hazard Function for a Student t Process
### Aliases: hstudent
### Keywords: distribution

### ** Examples

hstudent(1:10, 3, 2, 5)



