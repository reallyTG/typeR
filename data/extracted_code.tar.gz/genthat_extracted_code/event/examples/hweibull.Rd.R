library(event)


### Name: hweibull
### Title: Log Hazard Function for a Weibull Process
### Aliases: hweibull
### Keywords: distribution

### ** Examples

hweibull(1:10, 1.5, 2)



