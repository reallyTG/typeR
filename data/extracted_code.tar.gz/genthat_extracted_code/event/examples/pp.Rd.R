library(event)


### Name: pp
### Title: Create a Point Process Vector from Times between Events
### Aliases: pp
### Keywords: manip

### ** Examples

y <- c(5,3,2,4)
py <- pp(y)
py



