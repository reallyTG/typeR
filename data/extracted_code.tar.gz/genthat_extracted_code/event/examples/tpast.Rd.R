library(event)


### Name: tpast
### Title: Create a Vector of Times Past since Previous Events for a Point
###   Process
### Aliases: tpast
### Keywords: manip

### ** Examples

y <- c(5,3,2,4)
ptime <- tpast(y)
ptime



