library(fda)


### Name: AmpPhaseDecomp
### Title: Decomposition for Amplitude and Phase Variation
### Aliases: AmpPhaseDecomp
### Keywords: smooth models

### ** Examples

#See the analysis for the growth data in the examples.



