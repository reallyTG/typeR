library(fda)


### Name: MontrealTemp
### Title: Montreal Daily Temperature
### Aliases: MontrealTemp
### Keywords: datasets

### ** Examples

data(MontrealTemp)

JanuaryThaw <- t(MontrealTemp[, 16:47])




