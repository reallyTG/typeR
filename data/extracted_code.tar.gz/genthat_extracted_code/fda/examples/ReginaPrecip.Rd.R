library(fda)


### Name: ReginaPrecip
### Title: Regina Daily Precipitation
### Aliases: ReginaPrecip
### Keywords: datasets

### ** Examples

data(ReginaPrecip)
hist(ReginaPrecip)




