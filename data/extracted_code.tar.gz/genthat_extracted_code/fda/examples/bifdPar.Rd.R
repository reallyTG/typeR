library(fda)


### Name: bifdPar
### Title: Define a Bivariate Functional Parameter Object
### Aliases: bifdPar
### Keywords: bivariate smooth

### ** Examples

#See the prediction of precipitation using temperature as
#the independent variable in the analysis of the daily weather
#data, and the analysis of the Swedish mortality data.



