library(fda)


### Name: create.constant.basis
### Title: Create a Constant Basis
### Aliases: create.constant.basis
### Keywords: smooth

### ** Examples


basisobj <- create.constant.basis(c(-1,1))




