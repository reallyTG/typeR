library(fda)


### Name: fRegress.CV
### Title: Computes Cross-validated Error Sum of Integrated Squared Errors
###   for a Functional Regression Model
### Aliases: fRegress.CV
### Keywords: smooth

### ** Examples

#See the analyses of the Canadian daily weather data.



