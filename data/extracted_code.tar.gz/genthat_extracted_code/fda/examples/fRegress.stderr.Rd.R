library(fda)


### Name: fRegress.stderr
### Title: Compute Standard errors of Coefficient Functions Estimated by
###   Functional Regression Analysis
### Aliases: fRegress.stderr
### Keywords: smooth

### ** Examples

#See the weather data analyses in the file daily.ssc for
#examples of the use of function fRegress.stderr.



