library(fda)


### Name: gait
### Title: Hip and knee angle while walking
### Aliases: gait
### Keywords: datasets

### ** Examples

plot(gait[,1, 1], gait[, 1, 2], type="b")



