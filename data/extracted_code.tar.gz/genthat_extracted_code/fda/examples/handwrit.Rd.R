library(fda)


### Name: handwrit
### Title: Cursive handwriting samples
### Aliases: handwrit handwritTime
### Keywords: datasets

### ** Examples

plot(handwrit[, 1, 1], handwrit[, 1, 2], type="l")



