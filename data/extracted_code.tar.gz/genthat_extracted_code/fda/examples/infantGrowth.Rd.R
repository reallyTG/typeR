library(fda)


### Name: infantGrowth
### Title: Tibia Length for One Baby
### Aliases: infantGrowth
### Keywords: datasets

### ** Examples

data(infantGrowth)
plot(tibiaLength~day, infantGrowth)



