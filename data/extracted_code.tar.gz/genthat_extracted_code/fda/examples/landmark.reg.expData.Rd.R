library(fda)


### Name: landmark.reg.expData
### Title: Experiment data for landmark registration and alignment
### Aliases: landmark.reg.expData sampleData
### Keywords: datasets

### ** Examples

data(landmark.reg.expData)
head(sampleData)



