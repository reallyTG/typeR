library(fda)


### Name: linmod
### Title: Fit Fully Functional Linear Model
### Aliases: linmod
### Keywords: smooth

### ** Examples

#See the prediction of precipitation using temperature as
#the independent variable in the analysis of the daily weather
#data, and the analysis of the Swedish mortality data.



