library(fda)


### Name: lip
### Title: Lip motion
### Aliases: lip lipmarks liptime
### Keywords: datasets

### ** Examples

#  See the lip demo.



