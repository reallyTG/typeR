library(fda)


### Name: melanoma
### Title: melanoma 1936-1972
### Aliases: melanoma
### Keywords: datasets

### ** Examples

plot(melanoma[, -1], type="b")



