library(fda)


### Name: nondurables
### Title: Nondurable goods index
### Aliases: nondurables
### Keywords: datasets

### ** Examples

plot(nondurables, log="y")



