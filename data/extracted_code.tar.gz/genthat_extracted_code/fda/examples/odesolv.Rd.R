library(fda)


### Name: odesolv
### Title: Numerical Solution mth Order Differential Equation System
### Aliases: odesolv
### Keywords: smooth

### ** Examples

#See the analyses of the lip data.



