library(fda)


### Name: onechild
### Title: growth in height of one 10-year-old boy
### Aliases: onechild
### Keywords: datasets

### ** Examples

with(onechild, plot(day, height, type="b"))




