library(fda)


### Name: ppBspline
### Title: Convert a B-spline function to piece-wise polynomial form
### Aliases: ppBspline
### Keywords: smooth

### ** Examples

  ppBspline(1:5)



