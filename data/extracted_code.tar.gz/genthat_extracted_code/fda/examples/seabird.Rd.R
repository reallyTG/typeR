library(fda)


### Name: seabird
### Title: Sea Bird Counts
### Aliases: seabird
### Keywords: datasets

### ** Examples

data(seabird)
## maybe str(seabird) ; plot(seabird) ...



