library(fda)


### Name: wtcheck
### Title: Check a vector of weights
### Aliases: wtcheck
### Keywords: logic

### ** Examples

wtcheck(3, 1:3)

wtcheck(2, matrix(1:2, 2))




