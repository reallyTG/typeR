library(gwrr)


### Name: columbus
### Title: Columbus crime
### Aliases: columbus
### Keywords: datasets

### ** Examples

data(columbus)
plot(columbus$x, columbus$y)



