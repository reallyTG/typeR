library(hypervolume)


### Name: expectation_ball
### Title: Hypersphere expectation
### Aliases: expectation_ball

### ** Examples

data(iris)
e_ball <- expectation_ball(iris[,1:3])



