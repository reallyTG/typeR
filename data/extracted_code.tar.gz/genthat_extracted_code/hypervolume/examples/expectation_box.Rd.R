library(hypervolume)


### Name: expectation_box
### Title: Hyperbox expectation
### Aliases: expectation_box

### ** Examples

data(iris)
e_box <- expectation_box(iris[,1:3])



