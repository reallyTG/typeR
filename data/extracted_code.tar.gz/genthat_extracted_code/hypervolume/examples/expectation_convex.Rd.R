library(hypervolume)


### Name: expectation_convex
### Title: Convex expectation
### Aliases: expectation_convex

### ** Examples

## Not run: 
##D data(iris)
##D e_convex <- expectation_convex(iris[,1:3], check.memory=FALSE)
## End(Not run)



