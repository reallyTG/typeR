library(ifultools)


### Name: decibel
### Title: Conversion to decibels
### Aliases: decibel
### Keywords: utilities

### ** Examples

decibel(c(1,10,100,1000), type=1)
decibel(c(1,10,100,1000), type=2)



