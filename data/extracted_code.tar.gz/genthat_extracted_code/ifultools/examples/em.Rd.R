library(ifultools)


### Name: em
### Title: Typesetting unit
### Aliases: em
### Keywords: utilities

### ** Examples

em()



