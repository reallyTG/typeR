library(ifultools)


### Name: ilogb
### Title: Integer truncation of logb output
### Aliases: ilogb
### Keywords: utilities

### ** Examples

## should return 3 
ilogb(8 - .Machine$double.eps, base=2)



