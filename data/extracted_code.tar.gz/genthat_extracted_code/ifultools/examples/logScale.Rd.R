library(ifultools)


### Name: logScale
### Title: Logarithmically spaced scale vector generation
### Aliases: logScale
### Keywords: utilities

### ** Examples

logScale(scale.min = 1, scale.max=34, scale.ratio=4)



