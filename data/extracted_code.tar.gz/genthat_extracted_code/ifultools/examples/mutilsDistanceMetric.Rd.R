library(ifultools)


### Name: mutilsDistanceMetric
### Title: L-p metric conversion
### Aliases: mutilsDistanceMetric
### Keywords: IO

### ** Examples

mutilsDistanceMetric(Inf)



