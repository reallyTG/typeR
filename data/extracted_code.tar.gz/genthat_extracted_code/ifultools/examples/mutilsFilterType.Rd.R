library(ifultools)


### Name: mutilsFilterType
### Title: Converts wavelet filter string to MUTILS enum type
### Aliases: mutilsFilterType
### Keywords: IO

### ** Examples

## map the Haar filter 
mutilsFilterType("haar")



