library(ifultools)


### Name: mutilsTransformType
### Title: Converts wavelet transform string to MUTILS enum type
### Aliases: mutilsTransformType
### Keywords: IO

### ** Examples

## map the MODWPT 
mutilsTransformType("modwpt")



