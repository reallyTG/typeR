library(ifultools)


### Name: nextDyadic
### Title: Next integer power of 2
### Aliases: nextDyadic
### Keywords: utilities

### ** Examples

nextDyadic(15)



