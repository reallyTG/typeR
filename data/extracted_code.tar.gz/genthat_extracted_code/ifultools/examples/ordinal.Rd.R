library(ifultools)


### Name: ordinal
### Title: Ordinal value conversion
### Aliases: ordinal
### Keywords: utilities

### ** Examples

ordinal(1)
ordinal(2)
ordinal(3)
ordinal(pi)
ordinal(123)
ordinal(124)
ordinal(1000)



