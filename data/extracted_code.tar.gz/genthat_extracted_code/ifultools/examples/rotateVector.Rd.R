library(ifultools)


### Name: rotateVector
### Title: Circularly vector rotation
### Aliases: rotateVector
### Keywords: utilities

### ** Examples

rotateVector(1:5, 2)
rotateVector(1:5, -2)



