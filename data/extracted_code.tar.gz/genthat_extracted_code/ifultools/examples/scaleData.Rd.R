library(ifultools)


### Name: scaleData
### Title: Scale numeric data
### Aliases: scaleData
### Keywords: utilities

### ** Examples

scaleData(c(1,10,100,1000),scale="db")



