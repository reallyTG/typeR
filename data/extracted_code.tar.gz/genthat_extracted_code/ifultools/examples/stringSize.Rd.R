library(ifultools)


### Name: stringSize
### Title: Size of a character string in current font
### Aliases: stringSize
### Keywords: hplot

### ** Examples

stringSize("What's for dinner?", adj=0, srt=45, cex=1.5)



