library(kml)


### Name: epipageShort
### Title: ~ Data: epipageShort ~
### Aliases: epipageShort
### Keywords: datasets documentation

### ** Examples

data(epipageShort)
str(epipageShort)



