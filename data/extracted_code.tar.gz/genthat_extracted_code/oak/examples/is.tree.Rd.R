library(oak)


### Name: is.tree
### Title: Test if an object is a tree
### Aliases: is.tree is.rtree

### ** Examples

## FALSE
is.tree(empty_tree())




