library(oak)


### Name: rev.rtree
### Title: Reverse a chain
### Aliases: rev.rtree

### ** Examples

(tr0 = c_("Bob", "Carl", "Daniel"))
(rev(tr0))




