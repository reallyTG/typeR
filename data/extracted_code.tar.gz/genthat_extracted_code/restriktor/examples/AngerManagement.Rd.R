library(restriktor)


### Name: AngerManagement
### Title: Reduction of aggression levels Dataset (4 treatment groups)
### Aliases: AngerManagement

### ** Examples

  head(AngerManagement)



