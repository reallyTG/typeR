library(restriktor)


### Name: Burns
### Title: Relation between the response variable PTSS and gender, age,
###   TBSA, guilt and anger.
### Aliases: Burns

### ** Examples

head(Burns)



