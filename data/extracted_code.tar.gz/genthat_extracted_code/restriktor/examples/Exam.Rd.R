library(restriktor)


### Name: Exam
### Title: Relation between exam scores and study hours, anxiety scores and
###   average point scores.
### Aliases: Exam

### ** Examples

head(Exam)



