library(restriktor)


### Name: Hurricanes
### Title: The Hurricanes Dataset
### Aliases: Hurricanes

### ** Examples

head(Hurricanes)



