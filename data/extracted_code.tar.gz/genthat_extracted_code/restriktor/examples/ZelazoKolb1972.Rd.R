library(restriktor)


### Name: ZelazoKolb1972
### Title: "Walking" in the newborn (4 treatment groups)
### Aliases: ZelazoKolb1972

### ** Examples

head(ZelazoKolb1972)



