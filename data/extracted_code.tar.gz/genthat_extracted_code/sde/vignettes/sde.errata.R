### R code from vignette source 'sde.errata.Rnw'

